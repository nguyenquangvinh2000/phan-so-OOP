//khai bao lop phan so
class Phanso
{
  private:
    int tu;
    int mau;
  public:
    void Print();//in ra phan so
    void setTu(int t);//gab gia tri cho tu 
    void setMau(int m);//gan gia tri cho mau 
    int getTu();//lay gia tri cua tu 
    int getMau();//lay gia tri cua mau 
};
